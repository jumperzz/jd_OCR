from distutils.core import setup

setup(
    name = 'wx_sdk',
    version = '1.0.0',
    py_modules = ['wx_sdk'],
    requires='requests',
    author = 'xuehaipeng',
    author_email = 'wanxiang@jd.com',
    url = 'http://wx.jcloud.com',
    description = 'wangxiang Python SDK',
)
